import React from 'react'

const AboutSection = () => {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
          <div>
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Why Organ Donation Matters
            </h2>
            <p className="mt-3 max-w-3xl text-lg text-gray-500">
              Every 10 minutes, someone is added to the organ transplant waiting list. 
              Currently, over 100,000 people in the United States are waiting for a life-saving organ transplant.
            </p>
            <div className="mt-8 space-y-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white">
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Save Lives</h3>
                  <p className="mt-2 text-base text-gray-500">
                    One organ donor can save up to 8 lives through organ donation.
                  </p>
                </div>
              </div>
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white">
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Restore Hope</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Tissue donation can enhance the lives of up to 75 people.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-8 lg:mt-0">
            <img
              className="rounded-lg shadow-lg"
              src="https://images.pexels.com/photos/7269622/pexels-photo-7269622.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              width="867"
              height="1300"
              alt="Flat lay of educational toy models of human organs for anatomy learning."
            />
          </div>
        </div>
      </div>
    </section>
  )
}

export default AboutSection
