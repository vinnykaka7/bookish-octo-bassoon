import React from 'react'

const ImpactSection = () => {
  const stats = [
    { number: '100,000+', label: 'People on waiting list' },
    { number: '8', label: 'Lives saved per donor' },
    { number: '75', label: 'Lives enhanced per donor' },
    { number: '17', label: 'People die daily waiting' }
  ]

  const organs = [
    {
      name: 'Heart',
      description: 'Can save a life with end-stage heart disease',
      image: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    },
    {
      name: 'Liver',
      description: 'Can be split to help two recipients',
      image: 'https://images.pexels.com/photos/7722927/pexels-photo-7722927.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    },
    {
      name: 'Kidneys',
      description: 'Most needed organ, can help two people',
      image: 'https://images.pexels.com/photos/3938022/pexels-photo-3938022.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    },
    {
      name: 'Lungs',
      description: 'Can help people with lung disease breathe again',
      image: 'https://images.pexels.com/photos/3376787/pexels-photo-3376787.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    }
  ]

  return (
    <section id="impact" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            The Impact of Your Decision
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Your choice to become an organ donor creates ripples of hope and healing
          </p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4 mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl font-bold text-primary-600">{stat.number}</div>
              <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Organs Grid */}
        <div>
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">
            Organs That Can Be Donated
          </h3>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {organs.map((organ, index) => (
              <div key={index} className="card">
                <img
                  className="w-full h-32 object-cover"
                  src={organ.image}
                  alt={organ.name}
                />
                <div className="p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">{organ.name}</h4>
                  <p className="text-sm text-gray-500">{organ.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default ImpactSection
