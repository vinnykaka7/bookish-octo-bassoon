import React from 'react'

const ProcessSection = () => {
  const steps = [
    {
      id: 1,
      title: 'Register Online',
      description: 'Sign up and complete your donor registration in just a few minutes.',
      image: 'https://images.pexels.com/photos/4269202/pexels-photo-4269202.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    },
    {
      id: 2,
      title: 'Medical Evaluation',
      description: 'Our medical team will review your information and health history.',
      image: 'https://images.pexels.com/photos/2280547/pexels-photo-2280547.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    },
    {
      id: 3,
      title: 'Save Lives',
      description: 'When the time comes, your donation will give others a second chance at life.',
      image: 'https://images.pexels.com/photos/6129207/pexels-photo-6129207.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    }
  ]

  return (
    <section id="process" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            How It Works
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Becoming an organ donor is simple and can make a profound difference
          </p>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {steps.map((step) => (
              <div key={step.id} className="card">
                <div className="aspect-w-16 aspect-h-9">
                  <img
                    className="w-full h-48 object-cover"
                    src={step.image}
                    alt={step.title}
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="flex items-center justify-center w-8 h-8 bg-primary-600 text-white rounded-full text-sm font-bold">
                      {step.id}
                    </div>
                    <h3 className="ml-3 text-lg font-medium text-gray-900">{step.title}</h3>
                  </div>
                  <p className="text-gray-500">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default ProcessSection
