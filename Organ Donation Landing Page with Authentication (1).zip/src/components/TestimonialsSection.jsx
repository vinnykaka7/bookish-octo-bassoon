import React from 'react'

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Heart Recipient',
      content: 'Thanks to my donor, I was able to see my daughter graduate college. Organ donation gave me a second chance at life.',
      image: 'https://images.pexels.com/photos/5452228/pexels-photo-5452228.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    },
    {
      name: 'Michael Chen',
      role: 'Kidney Recipient',
      content: 'After 3 years on dialysis, receiving a kidney transplant changed everything. I can now live life to the fullest.',
      image: 'https://images.pexels.com/photos/4269202/pexels-photo-4269202.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
    }
  ]

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Stories of Hope
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Real stories from people whose lives were transformed by organ donation
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="card">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <img
                    className="w-12 h-12 rounded-full object-cover"
                    src={testimonial.image}
                    alt={testimonial.name}
                  />
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
                <blockquote className="text-gray-600 italic">
                  "{testimonial.content}"
                </blockquote>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default TestimonialsSection
