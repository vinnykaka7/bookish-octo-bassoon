import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { Link } from 'react-router-dom'

const Dashboard = () => {
  const { user, logout } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')

  const stats = [
    { label: 'Lives Potentially Saved', value: '8', color: 'text-green-600' },
    { label: 'Lives Potentially Enhanced', value: '75', color: 'text-blue-600' },
    { label: 'Registration Status', value: user?.donorStatus || 'Pending', color: 'text-yellow-600' },
    { label: 'Organs Registered', value: user?.organsRegistered?.length || 0, color: 'text-purple-600' }
  ]

  const organOptions = [
    'Heart', 'Liver', 'Kidneys', 'Lungs', 'Pancreas', 'Small Intestine', 'Corneas', 'Tissue'
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                </svg>
              </div>
              <span className="text-xl font-bold text-gray-900">LifeShare</span>
            </Link>
            
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">Welcome, {user?.name}</span>
              <button
                onClick={logout}
                className="text-gray-600 hover:text-primary-600 transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Donor Dashboard</h1>
          <p className="mt-2 text-gray-600">Manage your organ donation preferences and track your impact</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg shadow p-6">
              <div className="text-2xl font-bold mb-2 text-gray-900">{stat.value}</div>
              <div className="text-sm text-gray-500">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'preferences', label: 'Donation Preferences' },
                { id: 'documents', label: 'Documents' },
                { id: 'impact', label: 'Your Impact' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Account Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Full Name</label>
                      <div className="mt-1 text-sm text-gray-900">{user?.name}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Email</label>
                      <div className="mt-1 text-sm text-gray-900">{user?.email}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Registration Status</label>
                      <div className="mt-1">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          user?.donorStatus === 'registered' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {user?.donorStatus === 'registered' ? 'Active Donor' : 'Pending Verification'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <button
                      onClick={() => setActiveTab('preferences')}
                      className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left"
                    >
                      <div className="font-medium text-gray-900">Update Preferences</div>
                      <div className="text-sm text-gray-500">Modify your organ donation choices</div>
                    </button>
                    <button
                      onClick={() => setActiveTab('documents')}
                      className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left"
                    >
                      <div className="font-medium text-gray-900">Download Card</div>
                      <div className="text-sm text-gray-500">Get your donor identification card</div>
                    </button>
                    <button
                      onClick={() => setActiveTab('impact')}
                      className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left"
                    >
                      <div className="font-medium text-gray-900">View Impact</div>
                      <div className="text-sm text-gray-500">See how you're making a difference</div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'preferences' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Organ Donation Preferences</h3>
                  <p className="text-sm text-gray-600 mb-6">
                    Select which organs and tissues you would like to donate. You can update these preferences at any time.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {organOptions.map((organ) => (
                      <label key={organ} className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          defaultChecked={user?.organsRegistered?.includes(organ)}
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                        />
                        <span className="text-sm text-gray-900">{organ}</span>
                      </label>
                    ))}
                  </div>
                  
                  <div className="mt-6">
                    <button className="btn-primary">
                      Update Preferences
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'documents' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Donor Documents</h3>
                  <div className="space-y-4">
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">Donor ID Card</h4>
                          <p className="text-sm text-gray-500">Official donor identification card</p>
                        </div>
                        <button className="btn-secondary">
                          Download
                        </button>
                      </div>
                    </div>
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">Registration Certificate</h4>
                          <p className="text-sm text-gray-500">Certificate of organ donor registration</p>
                        </div>
                        <button className="btn-secondary">
                          Download
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'impact' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Your Potential Impact</h3>
                  <div className="bg-gradient-to-r from-primary-50 to-blue-50 rounded-lg p-6 mb-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary-600 mb-2">83</div>
                      <div className="text-sm text-gray-600">Lives you could potentially save and enhance</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white border border-gray-200 rounded-lg p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Lives Saved</h4>
                      <div className="text-2xl font-bold text-green-600 mb-1">8</div>
                      <p className="text-sm text-gray-500">Through organ donation</p>
                    </div>
                    <div className="bg-white border border-gray-200 rounded-lg p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Lives Enhanced</h4>
                      <div className="text-2xl font-bold text-blue-600 mb-1">75</div>
                      <p className="text-sm text-gray-500">Through tissue donation</p>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h4 className="font-medium text-gray-900 mb-4">Share Your Story</h4>
                    <p className="text-sm text-gray-600 mb-4">
                      Help inspire others by sharing why you chose to become an organ donor.
                    </p>
                    <button className="btn-primary">
                      Share on Social Media
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
